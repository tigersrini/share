"""
3D STL Panel Packing – Full 3D Surface-to-Surface
===================================================
Packs STL parts with >=50mm surface gap.
- 24 axis-aligned + 30 random rotations, keep top 4 distinct per part
- True 3D greedy placement: try 6 approach directions per placed part
- Binary-search for tightest surface fit
- Nelder-Mead 3D polish on winner
"""

import os, sys, itertools, time
import numpy as np
import trimesh
from scipy.spatial import cKDTree
from scipy.optimize import minimize
from scipy.spatial.transform import Rotation

# ── CONFIG ─────────────────────────────────────────────────────────────────
STL_FOLDER = r"C:\Users\NTBI45696\Desktop\Cad_rev_comparisson\PANEL_STACK"
MIN_GAP_MM = 50.0

# ── Rotation library ──────────────────────────────────────────────────────
def _build_rotations():
    rots = []
    # 24 axis-aligned
    for perm in itertools.permutations(range(3)):
        for signs in itertools.product([-1, 1], repeat=3):
            mat = np.zeros((3, 3))
            for i, (p, s) in enumerate(zip(perm, signs)):
                mat[i, p] = s
            if np.linalg.det(mat) > 0:
                rots.append(mat)
    # 30 random (includes 45° tilts, arbitrary angles)
    np.random.seed(42)
    rots += list(Rotation.random(30).as_matrix())
    return rots

ALL_ROTS = _build_rotations()  # 54 total


# ── Helpers ────────────────────────────────────────────────────────────────
def load_meshes(folder):
    meshes = []
    for f in sorted(os.listdir(folder)):
        if f.lower().endswith(".stl"):
            m = trimesh.load(os.path.join(folder, f), force="mesh")
            meshes.append((f, m))
    return meshes


def rotated_centered(mesh_verts, R):
    v = mesh_verts @ R.T
    v -= (v.min(axis=0) + v.max(axis=0)) / 2.0
    return v


def sample_surface(verts, faces, count):
    m = trimesh.Trimesh(vertices=verts, faces=faces, process=False)
    pts, _ = trimesh.sample.sample_surface(m, count)
    return np.ascontiguousarray(pts)


def ranked_rotations(mesh_verts, top_k=4):
    """Keep top_k rotations with distinct UNSORTED extents (different axis mappings)."""
    results = []
    for R in ALL_ROTS:
        rv = mesh_verts @ R.T
        ext = rv.max(axis=0) - rv.min(axis=0)
        results.append((ext.prod(), R, ext))
    results.sort(key=lambda x: x[0])

    kept = [results[0]]
    for r in results[1:]:
        if len(kept) >= top_k:
            break
        # Keep if the UNSORTED extent vector differs by >30mm in any axis
        is_new = True
        for k in kept:
            if all(abs(a - b) < 30 for a, b in zip(r[2], k[2])):
                is_new = False
                break
        if is_new:
            kept.append(r)
    return kept


def min_surface_gap(pts_a, tree_a, pts_b, tree_b, offset):
    """Bidirectional min surface dist. offset = center_b - center_a."""
    d1, _ = tree_b.query(pts_a - offset, k=1)
    d2, _ = tree_a.query(pts_b + offset, k=1)
    return min(d1.min(), d2.min())


# ── 3D Placement ─────────────────────────────────────────────────────────
def binary_search_approach(new_pts, new_tree, placed_list, axis, sign, ref_center, gap):
    """Binary-search how close new_part can approach along axis*sign from ref_center,
    while satisfying gap against ALL placed parts. Returns 3D center for new part."""
    # Estimate max needed distance
    max_extent = 0
    for p in placed_list:
        max_extent = max(max_extent, np.ptp(p['pts'][:, axis]))
    max_extent = max(max_extent, np.ptp(new_pts[:, axis]))
    hi = max_extent + gap + 100.0  # guaranteed safe
    lo = 0.0

    for _ in range(15):
        mid = (lo + hi) / 2.0
        test_center = ref_center.copy()
        test_center[axis] += sign * mid

        # Check gap against all placed parts
        ok = True
        for p in placed_list:
            off = test_center - p['center']
            d = min_surface_gap(new_pts, new_tree, p['pts'], p['tree'], off)
            if d < gap:
                ok = False
                break
        if ok:
            hi = mid
        else:
            lo = mid

    final_center = ref_center.copy()
    final_center[axis] += sign * hi
    return final_center


def greedy_place_3d(parts_data, gap, order):
    """Place parts greedily in 3D. Each new part tries 6 directions from each placed part.
    Returns (volume, centers_orig_idx, bb) or (inf, None, None)."""
    n = len(parts_data)
    ordered = [parts_data[o] for o in order]

    # First part at origin
    placed = [{'pts': ordered[0][0], 'tree': ordered[0][1], 'center': np.zeros(3)}]

    for p in range(1, n):
        new_pts, new_tree = ordered[p][0], ordered[p][1]
        best_vol = np.inf
        best_center = None

        # Try approaching from 6 directions relative to each placed part
        for ref_idx in range(len(placed)):
            ref_center = placed[ref_idx]['center']
            for axis in range(3):
                for sign in [1.0, -1.0]:
                    nc = binary_search_approach(
                        new_pts, new_tree, placed, axis, sign, ref_center, gap
                    )

                    # Verify all gaps
                    ok = True
                    for pl in placed:
                        off = nc - pl['center']
                        d = min_surface_gap(new_pts, new_tree, pl['pts'], pl['tree'], off)
                        if d < gap - 3.0:
                            ok = False
                            break

                    if not ok:
                        continue

                    # Compute bounding box volume
                    pts_list = [pl['pts'] + pl['center'] for pl in placed]
                    pts_list.append(new_pts + nc)
                    cloud = np.vstack(pts_list)
                    bb = cloud.max(axis=0) - cloud.min(axis=0)
                    vol = bb.prod()

                    if vol < best_vol:
                        best_vol = vol
                        best_center = nc.copy()

        if best_center is None:
            return np.inf, None, None

        placed.append({'pts': new_pts, 'tree': new_tree, 'center': best_center})

    # Map back to original indices
    orig_centers = [None] * n
    for rank, oidx in enumerate(order):
        orig_centers[oidx] = placed[rank]['center']

    cloud = np.vstack([parts_data[i][0] + orig_centers[i] for i in range(n)])
    bb = cloud.max(axis=0) - cloud.min(axis=0)
    return bb.prod(), orig_centers, bb


def pack_panels(meshes, gap, top_rots=4, sample_n=1200):
    n = len(meshes)
    print(f"\n── Surface packing (gap={gap}mm, up to {top_rots} rots/part, {sample_n} samples) ──")

    per_part = []
    for name, mesh in meshes:
        ranked = ranked_rotations(mesh.vertices, top_k=top_rots)
        variants = []
        for vol, R, ext in ranked:
            rv = rotated_centered(mesh.vertices, R)
            pts = sample_surface(rv, mesh.faces, sample_n)
            tree = cKDTree(pts)
            variants.append((pts, tree, ext, R))
        per_part.append(variants)
        print(f"  {name}: {len(ranked)} distinct rotations")
        for _, _, ext in ranked:
            print(f"    AABB {ext[0]:.0f} x {ext[1]:.0f} x {ext[2]:.0f} mm")

    orderings = list(itertools.permutations(range(n)))
    combo_total = 1
    for pp in per_part:
        combo_total *= len(pp)
    total_tries = combo_total * len(orderings)

    print(f"\n  {combo_total} rot combos x {len(orderings)} orderings = {total_tries} arrangements")
    print(f"  Each tries 6 directions x {n-1} refs → full 3D placement\n")

    t0 = time.time()
    best_vol = np.inf
    best_result = None
    tried = 0

    for combo in itertools.product(*per_part):
        parts_data = list(combo)
        for order in orderings:
            tried += 1
            vol, centers, bb = greedy_place_3d(parts_data, gap, order)

            if vol < best_vol and centers is not None:
                best_vol = vol
                best_result = {
                    'rots': [pd[3] for pd in parts_data],
                    'aabb_exts': [pd[2] for pd in parts_data],
                    'centers': centers,
                    'bb': bb,
                }
                print(f"    [{tried}/{total_tries}] NEW BEST: "
                      f"{bb[0]:.0f} x {bb[1]:.0f} x {bb[2]:.0f} mm  "
                      f"vol={vol/1e9:.4f} m^3  ({time.time()-t0:.1f}s)")

        elapsed = time.time() - t0
        combo_idx = tried // len(orderings)
        if combo_idx % 3 == 0:
            print(f"    ... combo {combo_idx}/{combo_total}  ({elapsed:.1f}s)")

    print(f"\n  Search done: {time.time()-t0:.1f}s  ({tried} arrangements)")
    return best_result


def polish_result(meshes, result, gap, hi_samples=4000):
    """Quick Nelder-Mead polish with denser samples."""
    print("\n── Final polish (Nelder-Mead, denser samples) ──")
    n = len(meshes)

    parts_verts = []
    samples = []
    trees = []
    for i in range(n):
        rv = rotated_centered(meshes[i][1].vertices, result['rots'][i])
        parts_verts.append(rv)
        pts = sample_surface(rv, meshes[i][1].faces, hi_samples)
        samples.append(pts)
        trees.append(cKDTree(pts))

    def objective(x):
        centers = [np.zeros(3)]
        for i in range(1, n):
            centers.append(np.array(x[(i-1)*3 : i*3]))

        penalty = 0.0
        for i in range(n):
            for j in range(i+1, n):
                off = centers[j] - centers[i]
                d1, _ = trees[j].query(samples[i] - off, k=1)
                d2, _ = trees[i].query(samples[j] + off, k=1)
                d = min(d1.min(), d2.min())
                if d < gap:
                    penalty += (gap - d) ** 2 * 1e6

        cloud = np.vstack([samples[i] + centers[i] for i in range(n)])
        span = cloud.max(axis=0) - cloud.min(axis=0)
        return span.prod() + penalty

    x0 = np.concatenate([result['centers'][i] for i in range(1, n)])
    res = minimize(objective, x0, method='Nelder-Mead',
                   options={'maxiter': 800, 'xatol': 1.0, 'fatol': 1e4, 'adaptive': True})

    final_centers = [np.zeros(3)]
    for i in range(1, n):
        final_centers.append(np.array(res.x[(i-1)*3 : i*3]))

    # Shift origin to positive
    cloud = np.vstack([samples[i] + final_centers[i] for i in range(n)])
    shift = cloud.min(axis=0)
    for i in range(n):
        final_centers[i] -= shift

    cloud = np.vstack([samples[i] + final_centers[i] for i in range(n)])
    span = cloud.max(axis=0) - cloud.min(axis=0)

    result['centers'] = final_centers
    result['samples'] = samples
    result['trees'] = trees
    result['parts_verts'] = parts_verts
    result['span'] = span
    result['volume'] = span.prod()
    print(f"  Result: {span[0]:.0f} x {span[1]:.0f} x {span[2]:.0f} mm  vol={span.prod()/1e9:.4f} m^3")
    return result


def print_report(meshes, best, gap):
    n = len(meshes)
    span = best['span']
    print(f"\n{'='*70}")
    print(f"  FINAL SURFACE-PACKED RESULT")
    print(f"{'='*70}")
    print(f"  Bounding box : {span[0]:.1f} x {span[1]:.1f} x {span[2]:.1f} mm")
    print(f"  Total volume : {best['volume']/1e9:.6f} m^3")
    print(f"  Min gap      : {gap:.0f} mm (surface-to-surface)\n")

    for i, (name, _) in enumerate(meshes):
        c = best['centers'][i]
        e = best['aabb_exts'][i]
        print(f"  Part {i+1}: {name}")
        print(f"    AABB  : {e[0]:.1f} x {e[1]:.1f} x {e[2]:.1f} mm")
        print(f"    Centre: ({c[0]:.1f}, {c[1]:.1f}, {c[2]:.1f}) mm\n")

    samples = best['samples']
    trees   = best['trees']
    print("  Surface gap verification:")
    for i in range(n):
        for j in range(i+1, n):
            off = best['centers'][j] - best['centers'][i]
            d = min_surface_gap(samples[i], trees[i], samples[j], trees[j], -off)
            status = "OK" if d >= gap - 2.0 else "WARNING"
            ni = meshes[i][0].replace(".stl", "")
            nj = meshes[j][0].replace(".stl", "")
            print(f"    {ni} <-> {nj}: {d:.1f} mm [{status}]")
    print(f"{'='*70}")


# ── VTK Visualisation ─────────────────────────────────────────────────────
def visualize(meshes, best, gap):
    import vtk

    n = len(meshes)
    centers = best['centers']
    span = best['span']
    samples = best['samples']
    trees = best['trees']
    parts_verts = best['parts_verts']

    colors = [(0.2,0.6,1.0),(1.0,0.4,0.2),(0.3,0.9,0.3)]

    ren = vtk.vtkRenderer()
    ren.SetBackground(0.12, 0.12, 0.18)

    for i, (name, mesh) in enumerate(meshes):
        verts = parts_verts[i] + centers[i]
        pts = vtk.vtkPoints()
        for v in verts:
            pts.InsertNextPoint(float(v[0]), float(v[1]), float(v[2]))

        polys = vtk.vtkCellArray()
        for face in mesh.faces:
            tri = vtk.vtkTriangle()
            for k in range(3):
                tri.GetPointIds().SetId(k, int(face[k]))
            polys.InsertNextCell(tri)

        pd = vtk.vtkPolyData()
        pd.SetPoints(pts)
        pd.SetPolys(polys)

        norms = vtk.vtkPolyDataNormals()
        norms.SetInputData(pd)
        norms.ComputePointNormalsOn()
        norms.Update()

        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(norms.GetOutputPort())

        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        col = colors[i % len(colors)]
        actor.GetProperty().SetColor(*col)
        actor.GetProperty().SetOpacity(0.85)
        actor.GetProperty().SetSpecular(0.3)
        ren.AddActor(actor)

        ext = best['aabb_exts'][i]
        cube = vtk.vtkCubeSource()
        cube.SetCenter(*(centers[i].tolist()))
        cube.SetXLength(float(ext[0]))
        cube.SetYLength(float(ext[1]))
        cube.SetZLength(float(ext[2]))
        ol = vtk.vtkOutlineFilter()
        ol.SetInputConnection(cube.GetOutputPort())
        om = vtk.vtkPolyDataMapper()
        om.SetInputConnection(ol.GetOutputPort())
        oa = vtk.vtkActor()
        oa.SetMapper(om)
        oa.GetProperty().SetColor(*col)
        oa.GetProperty().SetLineWidth(2)
        ren.AddActor(oa)

        lbl = vtk.vtkBillboardTextActor3D()
        lbl.SetInput(name.replace(".stl", ""))
        lbl.SetPosition(float(centers[i][0]), float(centers[i][1]+ext[1]/2+20), float(centers[i][2]))
        lbl.GetTextProperty().SetFontSize(14)
        lbl.GetTextProperty().SetColor(*col)
        lbl.GetTextProperty().SetBold(True)
        ren.AddActor(lbl)

    # Gap annotation lines between closest points
    for i in range(n):
        for j in range(i+1, n):
            off = centers[j] - centers[i]
            shifted = samples[i] - off
            dists, idxs = trees[j].query(shifted, k=1)
            ca = int(np.argmin(dists))
            cb = int(idxs[ca])
            pa = samples[i][ca] + centers[i]
            pb = samples[j][cb] + centers[j]
            d = float(dists.min())

            ls = vtk.vtkLineSource()
            ls.SetPoint1(*(pa.tolist()))
            ls.SetPoint2(*(pb.tolist()))
            lm = vtk.vtkPolyDataMapper()
            lm.SetInputConnection(ls.GetOutputPort())
            la = vtk.vtkActor()
            la.SetMapper(lm)
            la.GetProperty().SetColor(1,1,0)
            la.GetProperty().SetLineWidth(3)
            ren.AddActor(la)

            mid = (pa + pb) / 2
            gl = vtk.vtkBillboardTextActor3D()
            gl.SetInput(f"{d:.1f} mm")
            gl.SetPosition(*(mid.tolist()))
            gl.GetTextProperty().SetFontSize(16)
            gl.GetTextProperty().SetColor(1,1,0)
            gl.GetTextProperty().SetBold(True)
            ren.AddActor(gl)

    # Overall box
    cloud = np.vstack([samples[i]+centers[i] for i in range(n)])
    omin, omax = cloud.min(axis=0), cloud.max(axis=0)
    oc = (omin+omax)/2
    ca = vtk.vtkCubeSource()
    ca.SetCenter(*(oc.tolist()))
    ca.SetXLength(float(span[0]))
    ca.SetYLength(float(span[1]))
    ca.SetZLength(float(span[2]))
    oaf = vtk.vtkOutlineFilter()
    oaf.SetInputConnection(ca.GetOutputPort())
    om2 = vtk.vtkPolyDataMapper()
    om2.SetInputConnection(oaf.GetOutputPort())
    oa2 = vtk.vtkActor()
    oa2.SetMapper(om2)
    oa2.GetProperty().SetColor(1,1,0)
    oa2.GetProperty().SetLineWidth(3)
    ren.AddActor(oa2)

    title = vtk.vtkTextActor()
    title.SetInput(f"SURFACE-PACKED  |  {span[0]:.0f} x {span[1]:.0f} x {span[2]:.0f} mm  |  "
                   f"Vol: {best['volume']/1e9:.4f} m^3  |  Gap >= {gap:.0f} mm")
    title.GetTextProperty().SetFontSize(16)
    title.GetTextProperty().SetColor(1,1,1)
    title.GetTextProperty().SetBold(True)
    title.SetPosition(10,10)
    ren.AddViewProp(title)

    ax = vtk.vtkAxesActor()
    ax.SetTotalLength(50,50,50)
    ren.AddActor(ax)

    rw = vtk.vtkRenderWindow()
    rw.SetSize(1400,900)
    rw.SetWindowName("Panel Packing - Surface-to-Surface (Fast)")
    rw.AddRenderer(ren)
    iren = vtk.vtkRenderWindowInteractor()
    iren.SetRenderWindow(rw)
    iren.SetInteractorStyle(vtk.vtkInteractorStyleTrackballCamera())
    ren.ResetCamera()
    ren.GetActiveCamera().Zoom(0.85)
    rw.Render()
    iren.Start()


# ── Main ───────────────────────────────────────────────────────────────────
def main():
    print("=" * 70)
    print("  3D PANEL PACKING – SURFACE-TO-SURFACE (FAST)")
    print(f"  Minimum gap: {MIN_GAP_MM} mm")
    print(f"  CPU cores:   {os.cpu_count()}")
    print("=" * 70)

    meshes = load_meshes(STL_FOLDER)
    if not meshes:
        print("ERROR: No STL files found!"); sys.exit(1)
    for name, m in meshes:
        e = m.bounding_box_oriented.extents
        print(f"  {name}: {len(m.faces)} faces, OBB {e[0]:.1f} x {e[1]:.1f} x {e[2]:.1f} mm")

    t0 = time.time()

    best = pack_panels(meshes, MIN_GAP_MM, top_rots=4, sample_n=1200)
    if best is None:
        print("ERROR: No feasible packing found!"); sys.exit(1)

    best = polish_result(meshes, best, MIN_GAP_MM, hi_samples=4000)

    total = time.time() - t0
    print(f"\n  TOTAL TIME: {total:.1f}s")

    print_report(meshes, best, MIN_GAP_MM)

    print("\nLaunching 3D visualisation ...")
    visualize(meshes, best, MIN_GAP_MM)


if __name__ == "__main__":
    main()
